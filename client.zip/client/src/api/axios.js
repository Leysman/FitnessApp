import axios from 'axios';
import store from '../store';        
import { logout } from '../redux/slices/authSlice';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL,     // или просто '/api'
  // сeрвер отдаёт токен в теле ответа
});

// Перед каждым запросом — подставляем токен из Redux
api.interceptors.request.use(      // Метод use регистрирует два колбэка: onFulfilled(config) и onRejected(error)
  (config) => {
    const { token } = store.getState().auth;
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;  // Если токен есть, добавляет в заголовки
    }
    return config; //необходимо, чтобы Axios получил обновлённые настройки и продолжил выполнение запроса.
  },
  (error) => Promise.reject(error)
);

// После ответа — ловим 401 и делаем logout
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // например, диспатчим выход и редирект на /login
      store.dispatch(logout());
    }
    return Promise.reject(error);
  }
);

export default api;